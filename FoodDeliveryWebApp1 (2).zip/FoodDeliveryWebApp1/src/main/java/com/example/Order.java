package com.example;

import java.util.ArrayList;
import java.util.List;

public class Order {
    private List<FoodItem> items;

    public Order() {
        this.items = new ArrayList<>();
    }

    public void addItem(FoodItem item) {
        items.add(item);
    }

    public List<FoodItem> getItems() {
        return items;
    }

    public double getTotalAmount() {
        // Calculate total amount based on items in the order
        double totalAmount = 0.0;
        for (FoodItem item : items) {
            totalAmount += item.getPrice();
        }
        return totalAmount;
    }
}