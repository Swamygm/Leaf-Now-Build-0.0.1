package com.example;
import java.util.List;
import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// Inside the MenuServlet.java file
@WebServlet("/menu")
public class MenuServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Logic to retrieve the menu items
        List<FoodItem> menu = getMenuItems(); // Replace with your logic to get menu items

        // Set menu items as a request attribute
        request.setAttribute("menu", menu);

        // Forward the request to menu.jsp
        RequestDispatcher dispatcher = request.getRequestDispatcher("menu.jsp");
        dispatcher.forward(request, response);
    }

    // Replace this method with your logic to get menu items
    private List<FoodItem> getMenuItems() {
        // Example logic to create a dummy menu
        List<FoodItem> menu = new ArrayList<>();
        menu.add(new FoodItem("Burger", 5.99));
        menu.add(new FoodItem("Pizza", 8.99));
        return menu;
    }
}
